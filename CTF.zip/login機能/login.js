async function getCSRFToken() {
    const res = await fetch("csrf_token.php", {
        credentials: "same-origin"
    });

    if (!res.ok) {
        throw new Error("トークン取得失敗");
    }

    const data = await res.json();

    if (!data.csrf_token) {
        throw new Error("トークン未取得");
    }

    return data.csrf_token;
}

document.getElementById("login-form").addEventListener("submit", async function(e) {
    e.preventDefault();

    const errorBox = document.getElementById("login-error");
    errorBox.textContent = ""; // 前回のエラーをクリア

    let token;
    try {
        token = await getCSRFToken();
    } catch (error) {
        console.error("トークン取得失敗：", error);
        errorBox.textContent= "通信エラーが発生しました";
        return;
    }
    
    try {
        const response = await fetch("check.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                csrf_tokens: token,
                email: document.getElementById("email").value,
                password: document.getElementById("password").value
            })
        });

        if(!response.ok) {
            errorBox.textContent = `ログイン失敗： ${response.status} ${response.statusText}`;
            return;
        }

        const result = await response.json();

        if (result.error) {
            errorBox.textContent = `ログイン失敗： ${result.error}`
        }
        console.log(result);
    } catch (error) {
        console.error("送信エラー:", error);
        errorBox.textContent ="ログインに失敗しました";
    }
})