<?php
    ini_set('session.use_only_cookies', 1);
    ini_set('session.use_strict_mode', 1);
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();

    header("Content-Type: application/json");

    if (!empty($_SESSION['csrf_tokens'])) {
        foreach ($_SESSION['csrf_tokens'] as $t => $time) {
            if ($time < time() - 300) {
                unset($_SESSION['csrf_tokens'][$t]);
            }
        }
    }

    $token = bin2hex(random_bytes(32));
    $_SESSION['csrf_tokens'][$token] = time();

    echo json_encode([
        "csrf_token" => $token
    ]);
?>