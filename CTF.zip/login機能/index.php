<?php
    session_start();

    if (empty($_SESSION['csrf_tokens'])) {
        $_SESSION['csrf_tokens'] = [];
    }

    $token = bin2hex(random_bytes(32));
    $_SESSION['csrf_tokens'][$token] = time();
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
    <title>ログインフォーム</title>
</head>
<body>
<form id="login-form">
    <input type="email" id="email" required placeholder="メールアドレス">
    <input type="password" id="password" required placeholder="パスワード">
    <button type="submit">Login</button>
    <div id="login-error" style="color:red; margin-top:7px;"></div>
</form>
<script src="login.js"></script>
</body>
</html>