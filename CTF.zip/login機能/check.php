
<?php
    ini_set('session.use_only_cookies', 1);
    ini_set('session.use_strict_mode', 1);

    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Strict'
    ]);

    session_start();
    header("Content-Type: application/json");

    if (stripos($_SERVER['CONTENT_TYPE'], 'application/json') === false) {
        http_response_code(415);
        echo json_encode(["error" => "Invalid Content-Type"]);
        exit;
    }

    $input = json_decode(file_get_contents("php://input"), true);

    $token = $input['csrf_tokens'] ?? '';
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';

    if (empty($_SESSION['csrf_tokens'][$token])) {
        http_response_code(403);
        echo json_encode(["error" => "Invalid CSRF token"]);
        exit;
    }

    unset($_SESSION['csrf_tokens'][$token]);

    if ($email === "test@example.com" && $password === "p@sSw0rd") {
        session_regenerate_id(true);

        $_SESSION['user'] = [
            "email" => $email
        ];

        echo json_encode([
            "status" => "ok"
        ]);
        exit;
    }

    http_response_code(401);
    echo json_encode(["error" => "Login failed"]);
?>