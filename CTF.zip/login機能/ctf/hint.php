<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit("Invalid request");
}

if (!isset($_POST['num'])) {
    exit("Invalid request");
}

$hints = [
    1 => "URLのホスト部分の扱いに注目してみましょう。",
    2 => "IPアドレスには複数の表記方法があります。",
    3 => "127.0.0.1 は 10進数1つで表現できます。"
];

$num = intval($_POST['num']);

if (!isset($hints[$num])) {
    exit("No hint");
}

echo $hints[$num];
?>