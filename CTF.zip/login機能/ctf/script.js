function loadHint(number) {
    fetch("hint.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "num=" + number
    })
    .then(res => res.text())
    .then(data => {
        if (data === "Invalid request") {
            alert("不正なアクセスです");
            return;
        }

        document.getElementById("hint" + number).innerHTML = data;
        document.getElementById("hint" + number).style.display = "block";

        if (number === 1) {
            document.getElementById("btn2").classList.remove("hidden");
        }

        if (number === 2) {
            document.getElementById("btn3").classList.remove("hidden");
        }
    });
}
