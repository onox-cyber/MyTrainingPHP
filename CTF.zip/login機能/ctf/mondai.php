<?php
$result = "";
function is_forbidden_ip($ip) {
    return (
        preg_match('/\A127\./', $ip) ||              // localhost
        preg_match('/\A10\./', $ip) ||               // private A
        preg_match('/\A192\.168\./', $ip) ||         // private C
        preg_match('/\A172\.(1[6-9]|2[0-9]|3[0-1])\./', $ip)
    );
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $url = $_POST["url"] ?? '';

    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        $result = "Invalid URL";
    } else {

        $parsed = parse_url($url);

        if (!isset($parsed['host'])) {
            $result = "Invalid host";
        } else {
            $host = $parsed['host'];
            /* ここから攻撃を想定 */
            if (is_forbidden_ip($host)) {
                $result = "Access denied (internal IP blocked).";
            } else {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT        => 3,
                    CURLOPT_FOLLOWLOCATION => true,
                ]);

                $response = curl_exec($ch);
                if ($response === false) {
                    $result = "cURL Error: " . curl_error($ch);
                } else {
                    $result = htmlspecialchars(substr($response, 0, 1500));
                }

                curl_close($ch);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Secure URL Preview</title>
    <link rel="stylesheet" href="/ctf/css/mondai.css">
</head>
<body>
<div class="container">
    <h2>URLプレビューサービス</h2>
    <form method="POST">
        <input type="text" name="url" placeholder="見てみたいサイトのURLを入力してください" required>
        <button type="submit">Fetch</button>
    </form>

    <div class="result">
        <?= $result ?>
    </div>
</div>
</body>
</html>
